/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.faces.bean.*;


/**
 *
 * @author desti
 */
//Destiny Velez

@ManagedBean(name="calculatorBean")
@RequestScoped
public class CalculatorBean {

    private int number1 ;

    private int number2;

    private int result;

    private int operator;

//getter and setter of number one
    public int getNumber1() {

        return number1;

    }

    public void setNumber1(int number1) {

        this.number1 = number1;

    }

//getter and setter of number two
    public int getNumber2() {

        return number2;

    }

    public void setNumber2(int number2) {

        this.number2 = number2;

    }

//getter and setter of result
    public int getResult() {

        return result;

    }

    public void setResult(int result) {

        this.result = result;

    }

//getter and setter of operator
    public int getOperator() {

        return operator;

    }

    public void setOperator(int operator) {

        this.operator = operator;

    }

    public String calculate() {

        switch (operator) {

            case 0:

                setResult(number1 + number2);

                break;

            case 1:

                setResult(number1 - number2);

                break;

            case 2:

                setResult(number1 * number2);

                break;

            case 3:

                setResult(number1 / number2);

                break;

            default:

                throw new RuntimeException("This operator is not supported");

        }

        return "answer.xhtml";

    }

}
